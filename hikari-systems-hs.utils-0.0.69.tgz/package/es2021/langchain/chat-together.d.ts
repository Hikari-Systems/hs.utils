import { BindToolsInput, SimpleChatModel, type BaseChatModelParams } from '@langchain/core/language_models/chat_models';
import { CallbackManagerForLLMRun } from '@langchain/core/callbacks/manager';
import { AIMessageChunk, ChatMessageChunk, HumanMessageChunk, SystemMessageChunk, ToolMessageChunk, type BaseMessage } from '@langchain/core/messages';
import { ChatGenerationChunk, ChatResult } from '@langchain/core/outputs';
import { Runnable } from '@langchain/core/runnables';
import { BaseFunctionCallOptions, BaseLanguageModelInput } from '@langchain/core/language_models/base';
interface ChatHSTogetherAIInput extends BaseChatModelParams {
    model: string;
    apiKey: string;
}
export interface ChatHSTogetherAICallOptions extends BaseFunctionCallOptions {
    tools?: any[];
}
export declare class ChatHSTogetherAI extends SimpleChatModel<ChatHSTogetherAICallOptions> {
    model: string;
    apiKey: string;
    constructor(fields: ChatHSTogetherAIInput);
    _llmType(): string;
    bindTools(tools: BindToolsInput[], kwargs?: Partial<ChatHSTogetherAICallOptions>): Runnable<BaseLanguageModelInput, AIMessageChunk, ChatHSTogetherAICallOptions>;
    _call(messages: BaseMessage[], options: this['ParsedCallOptions'], runManager?: CallbackManagerForLLMRun): Promise<string>;
    /** @ignore */
    _generate(messages: BaseMessage[], options: this['ParsedCallOptions'], runManager?: CallbackManagerForLLMRun): Promise<ChatResult>;
    protected _convertOpenAIDeltaToBaseMessageChunk(delta: Record<string, any>, id: string, defaultRole?: string): AIMessageChunk<import("@langchain/core/messages").MessageStructure<import("@langchain/core/messages").MessageToolSet>> | HumanMessageChunk<import("@langchain/core/messages").MessageStructure<import("@langchain/core/messages").MessageToolSet>> | SystemMessageChunk<import("@langchain/core/messages").MessageStructure<import("@langchain/core/messages").MessageToolSet>> | ToolMessageChunk<import("@langchain/core/messages").MessageStructure<import("@langchain/core/messages").MessageToolSet>> | ChatMessageChunk<import("@langchain/core/messages").MessageStructure<import("@langchain/core/messages").MessageToolSet>>;
    _streamResponseChunks(messages: BaseMessage[], options: this['ParsedCallOptions'], runManager?: CallbackManagerForLLMRun): AsyncGenerator<ChatGenerationChunk>;
}
export {};
