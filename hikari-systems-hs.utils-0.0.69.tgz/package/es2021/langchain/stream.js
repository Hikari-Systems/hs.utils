"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.llmResponseForConversation = exports.serveResponseFromGraph = exports.getModel = exports.getCheckpointSaver = exports.convertToLangchainTool = void 0;
const uuid_1 = require("uuid");
const messages_1 = require("@langchain/core/messages");
// import { BaseCheckpointSaver } from '@langchain/langgraph';
// import { ChatOllama } from '@langchain/ollama';
const aws_1 = require("@langchain/aws");
const openai_1 = require("@langchain/openai");
const prebuilt_1 = require("@langchain/langgraph/prebuilt");
const langgraph_checkpoint_1 = require("@langchain/langgraph-checkpoint");
const langgraph_checkpoint_postgres_1 = require("@langchain/langgraph-checkpoint-postgres");
const tools_1 = require("@langchain/core/tools");
const zod_1 = require("zod");
const config_1 = __importDefault(require("../config"));
const logging_1 = __importDefault(require("../logging"));
const chat_together_1 = require("./chat-together");
const pgconfig_1 = require("../pg/pgconfig");
const log = (0, logging_1.default)('langchain:stream');
const { configString, configInteger, configFloat, configBoolean } = config_1.default;
const wrapZodNodeWithDesc = (item, ad) => {
    const itemNullable = ad.required ? item : item.nullable();
    return itemNullable.describe(ad.description);
};
const convertToLangchainTool = (def) => (0, tools_1.tool)(async (input) => def.callable(input), {
    name: def.name,
    description: def.description,
    schema: zod_1.z.object(def.argDefs.reduce((acc, ad) => {
        if (ad.type === 'number') {
            acc[ad.name] = wrapZodNodeWithDesc(zod_1.z.number(), ad);
        }
        else if (ad.type === 'date') {
            acc[ad.name] = wrapZodNodeWithDesc(zod_1.z.date(), ad);
        }
        else {
            acc[ad.name] = wrapZodNodeWithDesc(zod_1.z.string(), ad);
        }
        return acc;
    }, {})),
});
exports.convertToLangchainTool = convertToLangchainTool;
const getCheckpointSaver = async (configPrefix = '') => {
    const checkpointerDBHost = configString(`${configPrefix}llm:checkpointer:db:host`, '');
    if (checkpointerDBHost !== '') {
        log.debug('Using postgres checkpointer');
        const checkpointer = new langgraph_checkpoint_postgres_1.PostgresSaver((0, pgconfig_1.getConnectionPoolFromConfigPrefix)('llm:checkpointer:db'));
        await checkpointer.setup();
        return checkpointer;
    }
    log.debug('Using memory checkpointer');
    return new langgraph_checkpoint_1.MemorySaver();
};
exports.getCheckpointSaver = getCheckpointSaver;
let checkpointSaver;
const getModel = async (configPrefix = '') => {
    const llmType = configString(`${configPrefix}llm:type`, 'openAI');
    const streaming = configBoolean(`${configPrefix}llm:streaming`, false);
    if (llmType === 'openAI') {
        const modelName = configString(`${configPrefix}llm:modelName`, 'gpt-4-turbo');
        const apiKey = configString(`${configPrefix}llm:apiKey`, '');
        const baseURL = configString(`${configPrefix}llm:baseUrl`, '');
        if (apiKey === '' && baseURL === '') {
            log.warn('WARNING: openAI api key and baseURL are both not set');
        }
        return new openai_1.ChatOpenAI({
            model: modelName,
            apiKey,
            streaming,
            configuration: baseURL === '' ? undefined : { baseURL },
        });
    }
    if (llmType === 'togetherAI') {
        const modelName = configString(`${configPrefix}llm:modelName`, 'meta-llama/Llama-3.3-70B-Instruct-Turbo');
        const apiKey = configString(`${configPrefix}llm:apiKey`, '');
        if (apiKey === '') {
            log.warn('WARNING: togetherAI api key is not set');
        }
        return new chat_together_1.ChatHSTogetherAI({
            model: modelName,
            apiKey,
        });
    }
    if (llmType === 'bedrock') {
        const modelName = configString(`${configPrefix}llm:modelName`, 'us.meta.llama3-3-70b-instruct-v1:0');
        const modelRegion = configString(`${configPrefix}llm:bedrock:modelRegion`, 'us-east-1');
        const maxTokens = configInteger(`${configPrefix}llm:bedrock:maxTokens`, 4096);
        const bedrockAccessKeyId = configString(`${configPrefix}llm:bedrock:awsAccessKeyId`, '');
        const bedrockSecretAccessKey = configString(`${configPrefix}llm:bedrock:awsSecretAccessKey`, '');
        const temperature = configFloat(`${configPrefix}llm:bedrock:temperature`, 0.5);
        if (bedrockAccessKeyId === '') {
            log.warn('WARNING: AWS bedrock accessKeyId is not set');
        }
        if (bedrockSecretAccessKey === '') {
            log.warn('WARNING: AWS bedrock secretAccessKey is not set');
        }
        return new aws_1.ChatBedrockConverse({
            model: modelName,
            region: modelRegion,
            streaming,
            maxTokens,
            temperature,
            credentials: {
                accessKeyId: bedrockAccessKeyId,
                secretAccessKey: bedrockSecretAccessKey,
            },
        });
    }
    throw new Error(`Unknown LLM type: ${llmType}`);
};
exports.getModel = getModel;
const serveResponseFromGraph = async (evt, graph, threadId, thisInput, streaming) => {
    try {
        if (!streaming) {
            const runId = (0, uuid_1.v4)();
            evt.emit('start', { runId });
            const result = await graph.invoke({
                messages: [thisInput],
            }, { configurable: { thread_id: threadId } });
            const { messages } = result;
            // log.debug(`Messages=${JSON.stringify(messages)}`);
            const output = messages[messages.length - 1].content;
            evt.emit('finish', { runId, output });
            return;
        }
        let runId;
        const eventStream = graph.streamEvents({
            messages: [thisInput],
        }, { version: 'v2', configurable: { thread_id: threadId } });
        // eslint-disable-next-line no-restricted-syntax
        for await (const event of eventStream) {
            // log.debug(`evt: ${JSON.stringify(event)}`);
            switch (event.event) {
                case 'on_chain_start': {
                    if (event.name === 'LangGraph') {
                        runId = event.run_id;
                        evt.emit('start', { runId });
                    }
                    break;
                }
                case 'on_chain_end': {
                    if (event.name === 'LangGraph') {
                        const { messages } = event.data.output;
                        const output = messages[messages.length - 1].content;
                        evt.emit('finish', { runId, output });
                    }
                    break;
                }
                case 'on_chat_model_stream': {
                    const content = event.data?.chunk?.content;
                    // log.debug(`on_chat_model_stream: ${content}`);
                    evt.emit('llmToken', { token: content, runId });
                    break;
                }
                // case 'on_tool_start': {
                //   log.debug(
                //     `Tool started: ${event.name} with inputs: ${event.data.input?.input}`,
                //   );
                //   break;
                // }
                // case 'on_tool_end': {
                //   log.debug(
                //     `Tool ended: ${event.name} with outputs: ${JSON.stringify(event.data.output?.content)}`,
                //   );
                //   break;
                // }
                default: {
                    // log.debug(`Unknown event type: ${JSON.stringify(event.event)}`);
                    break;
                }
            }
        }
    }
    catch (err) {
        log.error(`Error communicating with AI: `, err);
        evt.emit('error', {
            message: 'Error communicating with AI (possibly check account balance?)',
        });
    }
};
exports.serveResponseFromGraph = serveResponseFromGraph;
const llmResponseForConversation = async (evt, llm, promptText, toolset, threadId, thisInputText, streaming) => {
    // log.debug(`Tools available: ${toolset.map((x) => x.name).join(', ')}`);
    const langchainTools = toolset.map(exports.convertToLangchainTool);
    if (langchainTools.length === 0) {
        throw new Error(`Langchain implementation requires at least one tool defined`);
    }
    if (checkpointSaver === undefined) {
        checkpointSaver = (0, exports.getCheckpointSaver)();
    }
    const graph = (0, prebuilt_1.createReactAgent)({
        llm,
        tools: langchainTools,
        checkpointSaver: await checkpointSaver,
        prompt: promptText,
    });
    return (0, exports.serveResponseFromGraph)(evt, graph, threadId, new messages_1.HumanMessage(thisInputText), streaming);
};
exports.llmResponseForConversation = llmResponseForConversation;
