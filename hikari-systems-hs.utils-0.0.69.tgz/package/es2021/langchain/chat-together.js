"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatHSTogetherAI = void 0;
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-underscore-dangle */
const chat_models_1 = require("@langchain/core/language_models/chat_models");
const messages_1 = require("@langchain/core/messages");
const outputs_1 = require("@langchain/core/outputs");
const together_ai_1 = __importDefault(require("together-ai"));
const function_calling_1 = require("@langchain/core/utils/function_calling");
const logging_1 = __importDefault(require("../logging"));
const log = (0, logging_1.default)('langchain:chatTogether');
const mapMessages = (messages) => messages.map((m) => {
    switch (m._getType()) {
        case 'system': {
            return { role: 'system', content: `${m.content}` };
        }
        case 'human': {
            return { role: 'user', content: `${m.content}` };
        }
        case 'ai': {
            const aiMsg = m;
            return {
                role: 'assistant',
                content: `${m.content}`,
                tool_calls: aiMsg.tool_calls?.length
                    ? aiMsg.tool_calls?.map((f, idx) => ({
                        index: idx,
                        id: f.id,
                        type: 'function',
                        function: {
                            name: f.name,
                            arguments: f.args,
                        },
                    }))
                    : undefined, // this probably needs better mapping
            };
        }
        case 'function':
        case 'tool': {
            const toolMsg = m;
            return {
                role: 'tool',
                content: `${m.content}`,
                tool_call_id: toolMsg.tool_call_id,
                name: toolMsg.name,
            };
        }
        default: {
            throw new Error(`Unknown message type: ${JSON.stringify(m)}`);
        }
    }
});
class ChatHSTogetherAI extends chat_models_1.SimpleChatModel {
    constructor(fields) {
        super(fields);
        this.model = fields.model || 'meta-llama/Llama-3.3-70B-Instruct-Turbo';
        this.apiKey = fields.apiKey || '';
    }
    // eslint-disable-next-line class-methods-use-this
    _llmType() {
        return 'hsTogetherAI';
    }
    bindTools(tools, kwargs) {
        return this.withConfig({
            tools: tools.map((tool) => (0, function_calling_1.convertToOpenAITool)(tool)),
            ...kwargs,
        });
    }
    async _call(messages, options, runManager) {
        if (!messages.length) {
            throw new Error('No messages provided.');
        }
        // Pass `runManager?.getChild()` when invoking internal runnables to enable tracing
        // await subRunnable.invoke(params, runManager?.getChild());
        if (typeof messages[0].content !== 'string') {
            throw new Error('Multimodal messages are not supported.');
        }
        // log.debug(`Messages sent to together: ${JSON.stringify(messages)}`);
        const together = new together_ai_1.default({
            apiKey: this.apiKey,
            // fetch: (x: any, init: any): any => {
            //   log.debug(`Fetch: ${JSON.stringify(x)} init=${JSON.stringify(init)}`);
            //   return fetch(x, init);
            // },
        });
        const response = await together.chat.completions.create({
            messages: mapMessages(messages),
            model: this.model,
            stream: false,
            tools: options.tools,
        });
        const choice = response?.choices?.[0];
        if (choice && choice.message) {
            const chunk = this._convertOpenAIDeltaToBaseMessageChunk(choice.message, response.id, 'assistant');
            const newTokenIndices = {
                prompt: 0, // options.promptIndex ?? 0,
                completion: choice.index ?? 0,
            };
            if (typeof chunk.content !== 'string') {
                throw new Error('[WARNING]: Received non-string content from TogetherAI. This is currently not supported.');
            }
            const generationInfo = {};
            if (choice.finish_reason != null) {
                generationInfo.finish_reason = choice.finish_reason;
                // Only include system fingerprint in the last chunk for now
                // to avoid concatenation issues
                // generationInfo.system_fingerprint = response.system_fingerprint;
                generationInfo.model_name = response.model;
            }
            const generationChunk = new outputs_1.ChatGenerationChunk({
                message: chunk,
                text: chunk.content,
                generationInfo,
            });
            await runManager?.handleLLMNewToken(generationChunk.text ?? '', newTokenIndices, undefined, undefined, undefined, { chunk: generationChunk });
            return chunk.content;
        }
        throw new Error(`Bad response from LLM: ${JSON.stringify(response)}`);
    }
    /** @ignore */
    async _generate(messages, options, 
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    runManager) {
        // log.debug(`Messages sent to together: ${JSON.stringify(messages)}`);
        const together = new together_ai_1.default({
            apiKey: this.apiKey,
            // fetch: (x: any, init: any): any => {
            //   log.debug(`Fetch: ${JSON.stringify(x)} init=${JSON.stringify(init)}`);
            //   return fetch(x, init);
            // },
        });
        const response = await together.chat.completions.create({
            messages: mapMessages(messages),
            model: this.model,
            stream: false,
            tools: options.tools,
        });
        const generations = [];
        for (const part of response?.choices ?? []) {
            if (!part.message) {
                continue;
            }
            const text = part.message?.content ?? '';
            const generation = {
                text,
                message: this._convertOpenAIDeltaToBaseMessageChunk(part.message, response.id, 'assistant'),
            };
            generation.generationInfo = {
                ...(part.finish_reason ? { finish_reason: part.finish_reason } : {}),
                ...(part.logprobs ? { logprobs: part.logprobs } : {}),
            };
            // Fields are not serialized unless passed to the constructor
            // Doing this ensures all fields on the message are serialized
            generation.message = new messages_1.AIMessage(Object.fromEntries(Object.entries(generation.message).filter(([key]) => !key.startsWith('lc_'))));
            generations.push(generation);
        }
        return {
            generations,
        };
    }
    // eslint-disable-next-line class-methods-use-this
    _convertOpenAIDeltaToBaseMessageChunk(delta, id, defaultRole) {
        // log.debug(`Delta=${JSON.stringify(delta)}`);
        const role = delta.role ?? defaultRole;
        const content = delta.content ?? '';
        let additional_kwargs;
        if (delta.tool_calls) {
            additional_kwargs = {
                tool_calls: delta.tool_calls,
            };
        }
        else {
            additional_kwargs = {};
        }
        // log.debug(
        //   `CHUNK: ${content} toolcalls=${JSON.stringify(delta.tool_calls)}`,
        // );
        if (role === 'user') {
            return new messages_1.HumanMessageChunk({ content });
        }
        if (role === 'assistant') {
            const toolCallChunks = [];
            if (Array.isArray(delta.tool_calls)) {
                for (const rawToolCall of delta.tool_calls) {
                    toolCallChunks.push({
                        name: rawToolCall.function?.name,
                        args: rawToolCall.function?.arguments,
                        id: rawToolCall.id,
                        index: rawToolCall.index,
                        type: 'tool_call_chunk',
                    });
                }
            }
            return new messages_1.AIMessageChunk({
                content,
                tool_call_chunks: toolCallChunks,
                additional_kwargs,
                id,
            });
        }
        if (role === 'system') {
            return new messages_1.SystemMessageChunk({ content });
        }
        if (role === 'developer') {
            return new messages_1.SystemMessageChunk({
                content,
                additional_kwargs: {
                    __openai_role__: 'developer',
                },
            });
        }
        if (role === 'tool') {
            return new messages_1.ToolMessageChunk({
                content,
                additional_kwargs,
                tool_call_id: delta.tool_call_id,
            });
        }
        return new messages_1.ChatMessageChunk({ content, role });
    }
    async *_streamResponseChunks(messages, options, runManager) {
        if (!messages.length) {
            throw new Error('No messages provided.');
        }
        if (typeof messages[0].content !== 'string') {
            throw new Error('Multimodal messages are not supported.');
        }
        // log.debug(
        //   `Messages sent to together for stream: ${JSON.stringify(messages)}`,
        // );
        const together = new together_ai_1.default({
            apiKey: this.apiKey,
            // fetch: (x: any, init: any): any => {
            //   log.debug(`Fetch: ${JSON.stringify(x)} init=${JSON.stringify(init)}`);
            //   return fetch(x, init);
            // },
        });
        const stream = await together.chat.completions.create({
            messages: mapMessages(messages),
            model: this.model,
            stream: true,
            tools: options.tools,
        });
        // Pass `runManager?.getChild()` when invoking internal runnables to enable tracing
        // await subRunnable.invoke(params, runManager?.getChild());
        let defaultRole;
        for await (const data of stream) {
            // const token = chunk.choices[0].delta.content || '';
            // yield new ChatGenerationChunk({
            //   message: new AIMessageChunk({
            //     content: token,
            //   }),
            //   text: token,
            // });
            // // Trigger the appropriate callback for new chunks
            // // eslint-disable-next-line no-await-in-loop
            // await runManager?.handleLLMNewToken(token);
            const choice = data?.choices?.[0];
            if (!choice) {
                continue;
            }
            const { delta } = choice;
            if (!delta) {
                continue;
            }
            const chunk = this._convertOpenAIDeltaToBaseMessageChunk(delta, data.id, defaultRole);
            defaultRole = delta.role ?? defaultRole;
            const newTokenIndices = {
                prompt: 0, // options.promptIndex ?? 0,
                completion: choice.index ?? 0,
            };
            if (typeof chunk.content !== 'string') {
                log.warn('[WARNING]: Received non-string content from TogetherAI. This is currently not supported.');
                continue;
            }
            const generationInfo = { ...newTokenIndices };
            if (choice.finish_reason != null) {
                generationInfo.finish_reason = choice.finish_reason;
                // Only include system fingerprint in the last chunk for now
                // to avoid concatenation issues
                generationInfo.system_fingerprint = data.system_fingerprint;
                generationInfo.model_name = data.model;
            }
            const generationChunk = new outputs_1.ChatGenerationChunk({
                message: chunk,
                text: chunk.content,
                generationInfo,
            });
            yield generationChunk;
            await runManager?.handleLLMNewToken(generationChunk.text ?? '', newTokenIndices, undefined, undefined, undefined, { chunk: generationChunk });
        }
    }
}
exports.ChatHSTogetherAI = ChatHSTogetherAI;
