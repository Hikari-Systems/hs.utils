"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.bearerMiddleware = exports.authorizeMiddleware = exports.getSessionRedirectStore = exports.DEFAULT_ERROR_HANDLER = exports.doAuthorizeRedirect = void 0;
const express_1 = __importDefault(require("express"));
const dayjs_1 = __importDefault(require("dayjs"));
const uuid_1 = require("uuid");
const config_1 = __importDefault(require("./config"));
const logging_1 = __importDefault(require("./logging"));
const forwardedFor_1 = require("./forwardedFor");
const log = (0, logging_1.default)('middleware:authentication');
const doTokenExchange = async (code, redirectUri) => {
    try {
        const response = await fetch(config_1.default.get('oauth2:tokenUrl'), {
            method: 'POST',
            body: JSON.stringify({
                client_id: config_1.default.get('oauth2:clientId'),
                client_secret: config_1.default.get('oauth2:clientSecret'),
                grant_type: 'authorization_code',
                redirect_uri: redirectUri,
                code,
            }),
            headers: {
                'Content-type': 'application/json',
            },
        });
        const tokenResponse = await response.text();
        log.debug(`Token exchange response is ${tokenResponse}`);
        return JSON.parse(tokenResponse);
    }
    catch (err) {
        log.error(`Error doing token exchange: ${code}`, err);
        throw err;
    }
};
const doTokenRefresh = async (refreshToken) => {
    try {
        const response = await fetch(config_1.default.get('oauth2:tokenUrl'), {
            method: 'POST',
            body: JSON.stringify({
                client_id: config_1.default.get('oauth2:clientId'),
                client_secret: config_1.default.get('oauth2:clientSecret'),
                grant_type: 'refresh_token',
                token: refreshToken,
            }),
            headers: {
                'Content-type': 'application/json',
            },
        });
        const tokenResponse = await response.text();
        log.debug(`Token refresh response  is ${tokenResponse}`);
        return JSON.parse(tokenResponse);
    }
    catch (err) {
        log.error(`Error doing token refresh: ${refreshToken}`, err);
        throw err;
    }
};
const getOauthProfileByToken = async (token) => {
    try {
        const response = await fetch(config_1.default.get('oauth2:profileUrl'), {
            headers: {
                'Content-type': 'application/json',
                Authorization: `Bearer ${token}`,
            },
        });
        const profileResponse = await response.text();
        log.debug(`Profile is ${profileResponse}`);
        return JSON.parse(profileResponse);
    }
    catch (err) {
        log.error(`Error doing profile download: ${token}`, err);
        throw err;
    }
};
const doUserRowCreation = async (dlProfile, getUserByEmail, addUserByEmail, getOauthProfileBySub, upsertOauthProfile, updateUserFromOauthProfile) => {
    let userId;
    let userAdded = false;
    if (!dlProfile.email) {
        const savedProfile = await getOauthProfileBySub(dlProfile.sub);
        if (!savedProfile) {
            const user = await addUserByEmail('', dlProfile);
            userId = user.id;
            userAdded = true;
        }
        else {
            userId = savedProfile.userId;
        }
    }
    else {
        let user = await getUserByEmail(dlProfile.email);
        if (!user) {
            user = await addUserByEmail(dlProfile.email, dlProfile);
            userAdded = true;
        }
        userId = user.id;
    }
    const oauthProfile = await upsertOauthProfile(dlProfile.sub, userId, JSON.stringify(dlProfile));
    if (updateUserFromOauthProfile && !userAdded) {
        await updateUserFromOauthProfile(userId, oauthProfile);
    }
    return userId;
};
const doAuthorizeRedirect = async (path, req, res, redirectStore, callbackUri = '/oauth2/callback') => {
    const { baseUrl } = (0, forwardedFor_1.forwardedFor)(req);
    const { ui_locales } = req.query;
    const redirectUri = `${baseUrl}${callbackUri}`;
    const stateKey = (0, uuid_1.v4)();
    await redirectStore.set(req, stateKey, `${baseUrl}${path}`);
    // build authorization url
    const authorizeUrl = new URL(`${config_1.default.get('oauth2:authorizeUrl')}`);
    authorizeUrl.searchParams.append('response_type', 'code');
    authorizeUrl.searchParams.append('client_id', config_1.default.get('oauth2:clientId'));
    authorizeUrl.searchParams.append('redirect_uri', redirectUri);
    authorizeUrl.searchParams.append('state', stateKey);
    authorizeUrl.searchParams.append('scope', config_1.default.get('oauth2:scopes'));
    if (ui_locales) {
        authorizeUrl.searchParams.append('ui_locales', ui_locales); // for auth0
    }
    log.debug(`Sending authorization request for ${req.url}: url=${authorizeUrl}`);
    return res.redirect(authorizeUrl.toString());
};
exports.doAuthorizeRedirect = doAuthorizeRedirect;
const DEFAULT_ERROR_HANDLER = (statusCode) => (inErr, _inReq, inRes) => {
    log.error(`Error ${statusCode}: ${inErr}`);
    inRes.status(statusCode).send('Error');
    return Promise.resolve();
};
exports.DEFAULT_ERROR_HANDLER = DEFAULT_ERROR_HANDLER;
const getSessionRedirectStore = () => ({
    get: async (req, stateKey) => (req.session.postLoginRedirects || {})[stateKey],
    set: async (req, stateKey, val) => {
        if (!req.session?.postLoginRedirects) {
            req.session.postLoginRedirects = {};
        }
        req.session.postLoginRedirects[stateKey] = val;
    },
    del: async (req, stateKey) => {
        if (!req.session?.postLoginRedirects) {
            req.session.postLoginRedirects = {};
        }
        delete req.session.postLoginRedirects[stateKey];
    },
});
exports.getSessionRedirectStore = getSessionRedirectStore;
const authorizeMiddleware = ({ pathConfigs, getUserByEmail, addUserByEmail, getOauthProfileBySub, upsertOauthProfile, updateUserFromOauthProfile = undefined, stateStore = (0, exports.getSessionRedirectStore)(), callbackErrorHandler = (0, exports.DEFAULT_ERROR_HANDLER)(400), callbackUri = '/oauth2/callback', }) => {
    const router = express_1.default.Router();
    router.get(callbackUri, async (req, res, next) => {
        const { code, state: stateKey, error, } = req.query;
        const { baseUrl } = (0, forwardedFor_1.forwardedFor)(req);
        log.debug(`Authorization callback: code=${code} state=${stateKey}${error ? ' error=' : ''}${error || ''}`);
        try {
            if (error) {
                throw new Error(error);
            }
            if (!code) {
                throw new Error('No code supplied');
            }
            const redirectUri = await stateStore.get(req, stateKey);
            if (!redirectUri) {
                throw new Error(`No state found: key=${stateKey}`);
            }
            const tokenResp = await doTokenExchange(code, `${baseUrl}${callbackUri}`);
            if (!tokenResp?.access_token) {
                throw new Error(`No access token in response`);
            }
            await stateStore.del(req, stateKey);
            const dlProfile = await getOauthProfileByToken(tokenResp?.access_token);
            const userId = await doUserRowCreation(dlProfile, getUserByEmail, addUserByEmail, getOauthProfileBySub, upsertOauthProfile, updateUserFromOauthProfile);
            req.session.user = {
                userId,
                accessToken: tokenResp.access_token,
                refreshToken: tokenResp?.refresh_token,
                expiresAt: tokenResp?.expires_in
                    ? (0, dayjs_1.default)().add(tokenResp.expires_in, 'second')
                    : null,
            };
            // validate state, get redirectUrl
            const origUrl = redirectUri || '/';
            log.debug(`Redirecting to ${origUrl}`);
            return res.redirect(origUrl);
        }
        catch (err) {
            return callbackErrorHandler(err, req, res, next);
        }
    });
    router.use(async (req, res, next) => {
        const path = req.baseUrl + req.path;
        const matchedPath = pathConfigs?.find((x) => x.regex.test(path));
        if (!matchedPath) {
            return next(new Error(`ERROR: No matching auth path config found at ${path}`));
        }
        req.getLoggedInUserId = () => {
            const user = req?.session?.user;
            return user?.userId || null;
        };
        req.getAccessToken = async () => {
            const user = req?.session?.user;
            if (!user) {
                return null;
            }
            if (!user.accessToken ||
                (user.expiresAt && user.expiresAt.isBefore((0, dayjs_1.default)()))) {
                if (user.refreshToken) {
                    const tokenResp = await doTokenRefresh(user.refreshToken);
                    req.session.user = {
                        userId: user.userId,
                        accessToken: tokenResp.access_token,
                        refreshToken: tokenResp?.refresh_token,
                        expiresAt: tokenResp?.expires_in
                            ? (0, dayjs_1.default)().add(tokenResp.expires_in, 'second')
                            : null,
                    };
                    return tokenResp.access_token || null;
                }
                req.session.user = {
                    userId: user.userId,
                    accessToken: null,
                    refreshToken: null,
                    expiresAt: null,
                };
                return null;
            }
            return user.accessToken || null;
        };
        if (matchedPath.whitelist) {
            // log.debug(`Auth: allowing whitelisted path ${path}`);
            return next();
        }
        const userId = req.getLoggedInUserId();
        if (matchedPath?.failFast) {
            if (!userId) {
                log.debug(`Auth: rejecting, not logged in on failfast path ${path}`);
                return res.status(401).send(`not logged in`);
            }
            // log.debug(`Authentication check passed (failfast): ${path}`);
            return next();
        }
        if (userId) {
            // log.debug(`Authentication check passed: ${path}`);
            return next();
        }
        return (0, exports.doAuthorizeRedirect)(req.url, req, res, stateStore, callbackUri);
    });
    return router;
};
exports.authorizeMiddleware = authorizeMiddleware;
/*
 * aim to keep the getLoggedInUser function returning the logged in user even if whitelisted
 */
const bearerMiddleware = ({ pathConfigs, getUserByEmail, addUserByEmail, getOauthProfileBySub, upsertOauthProfile, updateUserFromOauthProfile = undefined, authErrorHandler = (0, exports.DEFAULT_ERROR_HANDLER)(401), }) => async (req, res, next) => {
    const path = req.baseUrl + req.path;
    const matchedPath = pathConfigs?.find((x) => x.regex.test(path));
    if (!matchedPath) {
        return next(new Error(`ERROR: No matching auth path config found at ${path}`));
    }
    const { whitelist: whitelisted } = matchedPath;
    const token = (() => {
        const authHeader = req.headers?.authorization?.trim();
        if (authHeader?.toLowerCase().startsWith('bearer ')) {
            return (authHeader || 'bearer ').substring(7).trim();
        }
        return '';
    })();
    if (!whitelisted && token === '') {
        return authErrorHandler(new Error(`No bearer/access token supplied`), req, res, next);
    }
    try {
        const userId = await (async () => {
            if ((token || '') === '') {
                return null; // must be whitelisted and not logged in
            }
            // Passing token to back end oauth-provider
            const dlProfile = await getOauthProfileByToken(token);
            const dlUserId = await doUserRowCreation(dlProfile, getUserByEmail, addUserByEmail, getOauthProfileBySub, upsertOauthProfile, updateUserFromOauthProfile);
            return dlUserId;
        })();
        req.getLoggedInUserId = () => userId || null;
        req.getAccessToken = async () => token === '' ? null : token;
        return next();
    }
    catch (err) {
        return authErrorHandler(err, req, res, next);
    }
};
exports.bearerMiddleware = bearerMiddleware;
