"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.forwardedFor = void 0;
const config_1 = __importDefault(require("./config"));
const forwardedFor = (req) => {
    const protocol = req.headers[`x-${config_1.default.get('server:x-prefix') || ''}forwarded-proto`] ||
        req.protocol ||
        'http';
    // port determination: use default for protocol if not specified, then override with XFF if supplied
    const defaultPortForProtocol = protocol === 'https' ? '443' : '80';
    const port = req.headers[`x-${config_1.default.get('server:x-prefix') || ''}forwarded-port`] ||
        defaultPortForProtocol;
    const host = req.headers[`x-${config_1.default.get('server:x-prefix') || ''}forwarded-host`] ||
        req.headers.host ||
        '';
    // rebuild the url from component parts
    const isStandardPort = (protocol === 'https' && port === '443') ||
        (protocol === 'http' && port === '80');
    const portSuffix = isStandardPort ? '' : `:${port}`;
    return {
        baseUrl: `${protocol}://${host}${portSuffix}`,
        fullUrl: `${protocol}://${host}${portSuffix}${req.originalUrl}`,
    };
};
exports.forwardedFor = forwardedFor;
exports.default = exports.forwardedFor;
