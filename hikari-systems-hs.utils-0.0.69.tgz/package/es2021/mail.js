"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createMailer = exports.getMailTransportConfig = exports.MAIL_TRANSPORT_CONFIG_PREFIX = void 0;
const handlebars_1 = __importDefault(require("handlebars"));
const nodemailer_1 = __importDefault(require("nodemailer"));
const promises_1 = require("fs/promises");
const fs_1 = require("fs");
const path_1 = require("path");
const config_1 = __importDefault(require("./config"));
const logging_1 = __importDefault(require("./logging"));
const dayjs_1 = __importDefault(require("dayjs"));
const log = (0, logging_1.default)('mail');
const { configString, configBoolean, configInteger } = config_1.default;
/** Config key prefix for transport options (includes trailing colon, e.g. mail:transport:). */
exports.MAIL_TRANSPORT_CONFIG_PREFIX = 'mail:transport:';
/**
 * Build nodemailer createTransport() options from hs.utils config.
 * Uses configString, configBoolean, and configInteger under the given prefix.
 * Only includes properties that are set (or have a non-empty default).
 *
 * Supported config keys under `prefix`:
 * - host, port, service, name, authMethod, localAddress (string/integer)
 * - user, pass (auth; auth only added if at least user is set)
 * - secure, ignoreTLS, requireTLS, opportunisticTLS (boolean)
 * - connectionTimeout, greetingTimeout, socketTimeout, dnsTimeout (integer ms)
 * - transactionLog, debug (boolean)
 * - tls:rejectUnauthorized (boolean), tls:minVersion (string)
 */
const getMailTransportConfig = (prefix = exports.MAIL_TRANSPORT_CONFIG_PREFIX) => {
    const host = configString(`${prefix}host`, '');
    const port = configInteger(`${prefix}port`, 0);
    const service = configString(`${prefix}service`, '');
    const secure = configBoolean(`${prefix}secure`, false);
    const ignoreTLS = configBoolean(`${prefix}ignoreTLS`, false);
    const requireTLS = configBoolean(`${prefix}requireTLS`, false);
    const opportunisticTLS = configBoolean(`${prefix}opportunisticTLS`, false);
    const user = configString(`${prefix}user`, '');
    const pass = configString(`${prefix}pass`, '');
    const name = configString(`${prefix}name`, '');
    const localAddress = configString(`${prefix}localAddress`, '');
    const authMethod = configString(`${prefix}authMethod`, '');
    const connectionTimeout = configInteger(`${prefix}connectionTimeout`, 0);
    const greetingTimeout = configInteger(`${prefix}greetingTimeout`, 0);
    const socketTimeout = configInteger(`${prefix}socketTimeout`, 0);
    const dnsTimeout = configInteger(`${prefix}dnsTimeout`, 0);
    const transactionLog = configBoolean(`${prefix}transactionLog`, false);
    const debug = configBoolean(`${prefix}debug`, false);
    const tlsRejectUnauthorized = configBoolean(`${prefix}tls:rejectUnauthorized`, true);
    const tlsMinVersion = configString(`${prefix}tls:minVersion`, '');
    const opts = {};
    if (host !== '')
        opts.host = host;
    if (port > 0)
        opts.port = port;
    if (service !== '')
        opts.service = service;
    opts.secure = secure;
    opts.ignoreTLS = ignoreTLS;
    opts.requireTLS = requireTLS;
    opts.opportunisticTLS = opportunisticTLS;
    if (user !== '') {
        opts.auth = { user, pass };
    }
    if (name !== '')
        opts.name = name;
    if (localAddress !== '')
        opts.localAddress = localAddress;
    if (authMethod !== '')
        opts.authMethod = authMethod;
    if (connectionTimeout > 0)
        opts.connectionTimeout = connectionTimeout;
    if (greetingTimeout > 0)
        opts.greetingTimeout = greetingTimeout;
    if (socketTimeout > 0)
        opts.socketTimeout = socketTimeout;
    if (dnsTimeout > 0)
        opts.dnsTimeout = dnsTimeout;
    opts.transactionLog = transactionLog;
    opts.debug = debug;
    if (!tlsRejectUnauthorized || tlsMinVersion !== '') {
        opts.tls = {};
        if (!tlsRejectUnauthorized)
            opts.tls.rejectUnauthorized = false;
        if (tlsMinVersion !== '')
            opts.tls.minVersion = tlsMinVersion;
    }
    return opts;
};
exports.getMailTransportConfig = getMailTransportConfig;
const createMailer = (templatePath) => {
    const mailConfig = (0, exports.getMailTransportConfig)();
    log.debug(`Creating mail transport: ${JSON.stringify(mailConfig)}`);
    const transport = nodemailer_1.default.createTransport(mailConfig);
    const mailPath = (template, ext) => (0, path_1.join)(templatePath, `${template}.${ext}.hbs`);
    const getMessageConfig = (template) => ({
        from: configString(`mail:messages:${template}:from`, ''),
        fromName: configString(`mail:messages:${template}:fromName`, ''),
        to: configString(`mail:messages:${template}:to`, ''),
        toName: configString(`mail:messages:${template}:toName`, ''),
        subject: configString(`mail:messages:${template}:subject`, ''),
    });
    const addVars = (data, template) => {
        const msg = getMessageConfig(template);
        const vars = {
            ...data,
            mailConfig: msg,
            dayjs: dayjs_1.default,
        };
        log.debug(`Seeding mail template with variables: ${JSON.stringify(vars)}`);
        return vars;
    };
    const renderConfigTemplate = (s, vars) => handlebars_1.default.compile(s)(vars).trim();
    const loadTemplate = async (template, ext) => {
        const path = mailPath(template, ext);
        if (!(0, fs_1.existsSync)(path)) {
            throw new Error(`Mail template not found: ${path}`);
        }
        return (0, promises_1.readFile)(path, { encoding: 'utf-8' });
    };
    const render = (ext) => async (template, data) => {
        const templateSource = await loadTemplate(template, ext);
        const compiled = handlebars_1.default.compile(templateSource);
        const vars = addVars(data, template);
        return compiled(vars);
    };
    const renderHtml = render('html');
    const renderText = async (template, data) => {
        const path = mailPath(template, 'text');
        if (!(0, fs_1.existsSync)(path)) {
            return null;
        }
        return render('text')(template, data);
    };
    const renderOptions = async (template, data) => {
        const vars = addVars(data, template);
        const msg = getMessageConfig(template);
        const defaultFrom = configString('mail:defaultFrom', '');
        const defaultFromName = configString('mail:defaultFromName', '');
        const defaultSubject = configString('mail:defaultSubject', '');
        const fromAddress = msg.from.trim() || defaultFrom;
        const from = fromAddress !== ''
            ? msg.fromName.trim() || defaultFromName
                ? {
                    name: msg.fromName.trim() || defaultFromName,
                    address: fromAddress,
                }
                : fromAddress
            : undefined;
        const toAddress = renderConfigTemplate(msg.to, vars);
        const toNameRendered = renderConfigTemplate(msg.toName || '', vars);
        const to = toAddress !== ''
            ? toNameRendered !== ''
                ? { name: toNameRendered, address: toAddress }
                : toAddress
            : undefined;
        const subjectRendered = renderConfigTemplate(msg.subject, vars);
        const subject = (subjectRendered !== '' ? subjectRendered : defaultSubject).trim();
        if (!from || !to || !subject) {
            throw new Error(`Missing mail:messages:${template} config (from, to, subject required)`);
        }
        const [html, text] = await Promise.all([
            renderHtml(template, data),
            renderText(template, data),
        ]);
        const resolvedFrom = from;
        const resolvedTo = to;
        const mailOptions = {
            from: resolvedFrom,
            to: resolvedTo,
            subject,
            html: html || undefined,
            text: text ?? undefined,
        };
        log.debug(`Parsed mail message to be sent: ${JSON.stringify(mailOptions)}`);
        return mailOptions;
    };
    const send = async (template, data) => {
        const mailOptions = await renderOptions(template, data);
        const fromStr = typeof mailOptions.from === 'string'
            ? mailOptions.from
            : `${mailOptions.from.name} <${mailOptions.from.address}>`;
        const toStr = typeof mailOptions.to === 'string'
            ? mailOptions.to
            : `${mailOptions.to.name} <${mailOptions.to.address}>`;
        const body = (mailOptions.html ?? mailOptions.text ?? '')
            .replace(/\s+/g, ' ')
            .trim();
        const bodyPreview = body.length > 50 ? `${body.slice(0, 50)}...` : body;
        log.info(`Sending mail from=${fromStr} to=${toStr} subject=${mailOptions.subject} body=${bodyPreview}`);
        const payload = {
            from: mailOptions.from,
            to: mailOptions.to,
            subject: mailOptions.subject,
            html: mailOptions.html ?? undefined,
            text: mailOptions.text ?? undefined,
        };
        return new Promise((resolve, reject) => {
            transport.sendMail(payload, (err, info) => {
                log.debug(`Mailer response: err=${err}, info=${JSON.stringify(info)}`);
                if (err) {
                    return reject(err);
                }
                return resolve();
            });
        });
    };
    return {
        render: renderHtml,
        renderHtml,
        renderText,
        renderOptions,
        send,
    };
};
exports.createMailer = createMailer;
