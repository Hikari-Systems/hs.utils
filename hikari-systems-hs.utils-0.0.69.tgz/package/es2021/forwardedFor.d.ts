import { Request } from 'express-serve-static-core';
export declare const forwardedFor: (req: Request) => {
    baseUrl: string;
    fullUrl: string;
};
export default forwardedFor;
