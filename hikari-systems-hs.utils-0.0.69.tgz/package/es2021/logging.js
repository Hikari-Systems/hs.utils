"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const winston_1 = require("winston");
const config_1 = __importDefault(require("./config"));
const level = config_1.default.get('log:level') || 'info';
const logging = (_name) => (0, winston_1.createLogger)({
    level,
    format: winston_1.format.simple(),
    transports: [new winston_1.transports.Console()],
});
exports.default = logging;
