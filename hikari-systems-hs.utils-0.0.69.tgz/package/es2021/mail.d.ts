import type SMTPTransport from 'nodemailer/lib/smtp-transport';
/** Config key prefix for transport options (includes trailing colon, e.g. mail:transport:). */
export declare const MAIL_TRANSPORT_CONFIG_PREFIX = "mail:transport:";
/**
 * Build nodemailer createTransport() options from hs.utils config.
 * Uses configString, configBoolean, and configInteger under the given prefix.
 * Only includes properties that are set (or have a non-empty default).
 *
 * Supported config keys under `prefix`:
 * - host, port, service, name, authMethod, localAddress (string/integer)
 * - user, pass (auth; auth only added if at least user is set)
 * - secure, ignoreTLS, requireTLS, opportunisticTLS (boolean)
 * - connectionTimeout, greetingTimeout, socketTimeout, dnsTimeout (integer ms)
 * - transactionLog, debug (boolean)
 * - tls:rejectUnauthorized (boolean), tls:minVersion (string)
 */
export declare const getMailTransportConfig: (prefix?: string) => SMTPTransport.Options;
export interface MailMessageConfig {
    from: string | {
        name: string;
        address: string;
    };
    to: string | {
        name: string;
        address: string;
    };
    subject: string;
}
export interface MailOptions {
    from: string | {
        name: string;
        address: string;
    };
    to: string | {
        name: string;
        address: string;
    };
    subject: string;
    text?: string | null;
    html?: string | null;
}
export type CreateMailer = (templatePath: string) => {
    render: (template: string, data: Record<string, unknown>) => Promise<string>;
    renderHtml: (template: string, data: Record<string, unknown>) => Promise<string>;
    renderText: (template: string, data: Record<string, unknown>) => Promise<string | null>;
    renderOptions: (template: string, data: Record<string, unknown>) => Promise<MailOptions>;
    send: (template: string, data: Record<string, unknown>) => Promise<void>;
};
export declare const createMailer: CreateMailer;
