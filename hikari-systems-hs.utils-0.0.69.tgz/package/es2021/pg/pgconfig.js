"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getConnectionPoolFromConfigPrefix = void 0;
const pg_1 = __importDefault(require("pg"));
const fs_1 = __importDefault(require("fs"));
const config_1 = __importDefault(require("../config"));
const { configString, configBoolean, configInteger } = config_1.default;
const getSslConfig = (prefix) => {
    if (!configBoolean(`${prefix}:ssl:enabled`)) {
        return false;
    }
    const rejectUnauthorized = configBoolean(`${prefix}:ssl:verify`);
    const caCertPath = configString(`${prefix}:ssl:caCertFile`);
    if (caCertPath === '') {
        return {
            rejectUnauthorized,
        };
    }
    return {
        rejectUnauthorized,
        ca: fs_1.default.readFileSync(caCertPath),
    };
};
const getConnectionPoolFromConfigPrefix = (prefix) => new pg_1.default.Pool({
    user: configString(`${prefix}:username`, ''),
    password: configString(`${prefix}:password`, ''),
    database: configString(`${prefix}:database`, 'hs_session'),
    host: configString(`${prefix}:host`, ''),
    port: configInteger(`${prefix}:port`, 5432),
    min: configInteger(`${prefix}:minpool`, 0),
    max: configInteger(`${prefix}:maxpool`, 3),
    ssl: getSslConfig(prefix),
});
exports.getConnectionPoolFromConfigPrefix = getConnectionPoolFromConfigPrefix;
