import pg from 'pg';
export declare const getConnectionPoolFromConfigPrefix: (prefix: string) => pg.Pool;
