declare const logging: (_name: string) => import("winston").Logger;
export default logging;
