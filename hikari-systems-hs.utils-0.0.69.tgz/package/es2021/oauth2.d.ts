import { LocalNextFunction, LocalRequest, LocalResponse } from './types';
export interface OauthProfileResponse {
    sub: string;
    given_name?: string;
    family_name?: string;
    name?: string;
    email?: string;
    email_verified?: boolean;
    nickname?: string;
    picture?: string;
    updated_at?: string;
}
export type GetUserByEmailFunction<U> = (email: string) => Promise<(U & {
    id: string;
}) | null>;
export type AddUserByEmailFunction<U> = (email: string, profile: OauthProfileResponse) => Promise<U & {
    id: string;
}>;
export type GetOauthProfileBySubFunction<O> = (sub: string) => Promise<O | null>;
export type UpsertOauthProfileFunction<O> = (sub: string, userId: string, profileJson: string) => Promise<O>;
export type UpdateUserFromOauthProfileFunction<U, O> = (userId: string, profile: O) => Promise<U>;
export interface UserBaseType {
    email: string;
}
export interface OauthProfileType {
    sub: string;
    userId: string;
    profileJson: OauthProfileResponse;
}
type ERROR_HANDLER_TYPE = (err: Error, req: LocalRequest, res: LocalResponse, next: LocalNextFunction) => Promise<void>;
export type RedirectStore = {
    get: (req: LocalRequest, stateKey: string) => Promise<string>;
    set: (req: LocalRequest, stateKey: string, val: string) => Promise<void>;
    del: (req: LocalRequest, stateKey: string) => Promise<void>;
};
export declare const doAuthorizeRedirect: (path: string, req: LocalRequest, res: LocalResponse, redirectStore: RedirectStore, callbackUri?: string) => Promise<void>;
export declare const DEFAULT_ERROR_HANDLER: (statusCode: number) => ERROR_HANDLER_TYPE;
export declare const getSessionRedirectStore: () => RedirectStore;
export interface Oauth2PathConfig {
    regex: RegExp;
    whitelist: boolean;
    failFast: boolean;
}
export interface AuthorizeMiddlewareProps<T extends UserBaseType, U extends OauthProfileType> {
    pathConfigs: Oauth2PathConfig[];
    getUserByEmail: GetUserByEmailFunction<T>;
    addUserByEmail: AddUserByEmailFunction<T>;
    getOauthProfileBySub: GetOauthProfileBySubFunction<U>;
    upsertOauthProfile: UpsertOauthProfileFunction<U>;
    updateUserFromOauthProfile?: UpdateUserFromOauthProfileFunction<T, U>;
    stateStore: RedirectStore;
    callbackErrorHandler: ERROR_HANDLER_TYPE;
    callbackUri: string;
}
export declare const authorizeMiddleware: <T extends UserBaseType, U extends OauthProfileType>({ pathConfigs, getUserByEmail, addUserByEmail, getOauthProfileBySub, upsertOauthProfile, updateUserFromOauthProfile, stateStore, callbackErrorHandler, callbackUri, }: AuthorizeMiddlewareProps<T, U>) => import("express-serve-static-core").Router;
export interface BearerMiddlewareProps<T extends UserBaseType, U extends OauthProfileType> {
    pathConfigs: Oauth2PathConfig[];
    getUserByEmail: GetUserByEmailFunction<T>;
    addUserByEmail: AddUserByEmailFunction<T>;
    getOauthProfileBySub: GetOauthProfileBySubFunction<U>;
    upsertOauthProfile: UpsertOauthProfileFunction<U>;
    updateUserFromOauthProfile?: UpdateUserFromOauthProfileFunction<T, U>;
    authErrorHandler: ERROR_HANDLER_TYPE;
}
export declare const bearerMiddleware: <T extends UserBaseType, U extends OauthProfileType>({ pathConfigs, getUserByEmail, addUserByEmail, getOauthProfileBySub, upsertOauthProfile, updateUserFromOauthProfile, authErrorHandler, }: BearerMiddlewareProps<T, U>) => (req: LocalRequest, res: LocalResponse, next: LocalNextFunction) => Promise<void>;
export {};
