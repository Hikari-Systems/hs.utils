import { LocalNextFunction, LocalRequest, LocalResponse } from '../types';
export declare const apiKeyMiddleware: (req: LocalRequest, res: LocalResponse, next: LocalNextFunction) => void | LocalResponse;
