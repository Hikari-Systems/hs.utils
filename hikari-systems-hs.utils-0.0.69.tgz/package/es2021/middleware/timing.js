"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.timingMiddleware = void 0;
const config_1 = __importDefault(require("../config"));
const logging_1 = __importDefault(require("../logging"));
const log = (0, logging_1.default)('server:timing');
const showCookies = (config_1.default.get('log:timing:showCookies') || 'false') === 'true';
const timingMiddleware = (req, res, next) => {
    const { cookie } = req.headers;
    const cookieMsg = showCookies && cookie && cookie !== '' ? ` cookie=${cookie}` : '';
    log.debug(`STARTED: ${req.method} ${req.originalUrl}${cookieMsg}`);
    const started = new Date();
    res.on('finish', () => {
        const duration = new Date().getTime() - started.getTime();
        log.debug(`COMPLETED in ${duration}ms: ${req.method} ${req.originalUrl}`);
    });
    return next();
};
exports.timingMiddleware = timingMiddleware;
