import { LocalNextFunction, LocalRequest, LocalResponse } from '../types';
export declare const timingMiddleware: (req: LocalRequest, res: LocalResponse, next: LocalNextFunction) => void;
