import { Store } from 'express-session';
import { LocalNextFunction, LocalRequest, LocalResponse } from '../types';
type StoreGetter = () => Promise<Store | undefined>;
export declare const sessionMiddleware: (storeGetter?: StoreGetter) => (req: LocalRequest, res: LocalResponse, next: LocalNextFunction) => Promise<void>;
export declare const redisStoreGetter: StoreGetter;
export declare const postgresStoreGetter: StoreGetter;
export {};
