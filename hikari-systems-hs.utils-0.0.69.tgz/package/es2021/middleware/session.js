"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.postgresStoreGetter = exports.redisStoreGetter = exports.sessionMiddleware = void 0;
const express_session_1 = __importStar(require("express-session"));
const connect_redis_1 = __importDefault(require("connect-redis"));
const connect_pg_simple_1 = __importDefault(require("connect-pg-simple"));
const ioredis_1 = __importDefault(require("ioredis"));
const config_1 = __importDefault(require("../config"));
const logging_1 = __importDefault(require("../logging"));
const pgconfig_1 = require("../pg/pgconfig");
const log = (0, logging_1.default)('middleware:session');
const { configString, configBoolean } = config_1.default;
const getSameSite = () => {
    const sameSiteStr = configString('session:sameSite', '');
    switch (sameSiteStr) {
        case 'true':
            return 'strict';
        case 'strict':
        case 'lax':
        case 'none':
            return sameSiteStr;
        default:
            return undefined;
    }
};
const memoryStore = new express_session_1.MemoryStore();
const memoryStoreGetter = () => Promise.resolve(memoryStore);
const sessionMiddleware = (storeGetter = memoryStoreGetter) => async (req, res, next) => {
    const baseConfig = {
        secret: configString('session:secret', ''),
        proxy: configBoolean('session:proxy', true),
        resave: configBoolean('session:resave', false),
        saveUninitialized: configBoolean('session:saveUninitialized', false),
        cookie: {
            httpOnly: configBoolean('session:httpOnly', false) || undefined,
            sameSite: getSameSite(),
            secure: configBoolean('session:secure', false) || undefined,
            signed: configBoolean('session:signed', false) || undefined,
        },
    };
    const store = (await storeGetter()) || (await memoryStoreGetter());
    return (0, express_session_1.default)({ ...baseConfig, store })(req, res, next);
};
exports.sessionMiddleware = sessionMiddleware;
// //////// REDIS IMPLEMENTATION - START
let redisStore;
const parseSentinelHosts = (hosts) => hosts.split(',').map((h) => {
    const [sentinelHost, portStr] = h.trim().split(':');
    return { host: sentinelHost, port: parseInt(portStr || '26379', 10) };
});
const redisStoreGetter = async () => {
    const url = configString('session:redis:url', '').trim();
    const host = configString('session:redis:host', '').trim();
    const sentinelHosts = configString('session:redis:sentinel:hosts', '').trim();
    if (url !== '' || host !== '' || sentinelHosts !== '') {
        if (!redisStore) {
            const auth = configString('session:redis:auth', '').trim() || undefined;
            const username = configString('session:redis:username', '').trim() || undefined;
            const db = parseInt(configString('session:redis:db', '0'), 10) || 0;
            const prefix = configString('session:prefix', '');
            const ioClient = sentinelHosts !== ''
                ? new ioredis_1.default({
                    sentinels: parseSentinelHosts(sentinelHosts),
                    name: configString('session:redis:sentinel:masterName', 'mymaster'),
                    db,
                    ...(auth && { password: auth }),
                    ...(username && { username }),
                })
                : url !== ''
                    ? new ioredis_1.default(url, { ...(auth && { password: auth }), db })
                    : new ioredis_1.default({
                        host,
                        port: parseInt(configString('session:redis:port', '6379'), 10) ||
                            6379,
                        db,
                        ...(auth && { password: auth }),
                        ...(username && { username }),
                    });
            ioClient.on('ready', () => {
                log.debug('Session redis connection available');
            });
            ioClient.on('error', (e) => {
                log.error('Error in session redis connection', e);
            });
            ioClient.on('reconnecting', () => {
                log.debug('Session redis connection interrupted - reconnecting');
            });
            ioClient.on('end', () => {
                log.debug('Session redis connection is disconnected');
            });
            redisStore = new connect_redis_1.default({ client: ioClient, prefix });
        }
        if (redisStore) {
            return redisStore;
        }
    }
    log.warn('WARNING: Redis session configuration missing: using in memory session store');
    return undefined;
};
exports.redisStoreGetter = redisStoreGetter;
// //////// REDIS IMPLEMENTATION - END
// //////// POSTGRES IMPLEMENTATION - START
const PGSession = (0, connect_pg_simple_1.default)(express_session_1.default);
let pgSessionStore;
const postgresStoreGetter = async () => {
    const host = (config_1.default.get('session:db:host') || '').trim();
    if (host !== '') {
        if (!pgSessionStore) {
            pgSessionStore = new PGSession({
                pool: (0, pgconfig_1.getConnectionPoolFromConfigPrefix)('session:db'),
                tableName: config_1.default.get('session:db:tableName') || 'session',
            });
        }
        if (pgSessionStore) {
            return pgSessionStore;
        }
    }
    log.warn('WARNING: PostgreSQL session configuration missing: using in memory session store');
    return undefined;
};
exports.postgresStoreGetter = postgresStoreGetter;
// //////// POSTGRES IMPLEMENTATION - END
