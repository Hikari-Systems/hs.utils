"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.apiKeyMiddleware = void 0;
const config_1 = __importDefault(require("../config"));
const logging_1 = __importDefault(require("../logging"));
const { configString } = config_1.default;
const log = (0, logging_1.default)('middleware:apikey');
const apiKeyMiddleware = (req, res, next) => {
    const apiKey = configString('server:apiKey', '');
    if (apiKey === '') {
        log.warn('WARNING: server:apiKey is not set, allowing all requests');
        return next();
    }
    const { 'X-Api-Key': apiKeyHeader } = req.headers;
    if (apiKeyHeader !== apiKey) {
        return res.status(401).send('Unauthorized: invalid API key');
    }
    return next();
};
exports.apiKeyMiddleware = apiKeyMiddleware;
