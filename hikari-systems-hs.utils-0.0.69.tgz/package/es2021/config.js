"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const nconf_1 = __importDefault(require("nconf"));
const fs_1 = require("fs");
const SECRET_PREFIX = '[SECRET]:';
const config = nconf_1.default
    .argv()
    .env('__')
    .file('environment', '/sandbox/config.json')
    .file('defaults', 'config.json');
const get = (key) => {
    const val = config.get(key);
    if (val && `${val}`.startsWith(SECRET_PREFIX)) {
        const filename = `${val}`.substring(SECRET_PREFIX.length);
        return (0, fs_1.readFileSync)(filename, { encoding: 'utf-8', flag: 'r' });
    }
    return val;
};
const getAllKeys = () => Object.keys(config.get());
const configString = (key, defaultValue = '') => String(get(key) ?? defaultValue).trim();
const configInteger = (key, defaultValue = 0) => {
    if (Number.isNaN(defaultValue) || !Number.isInteger(defaultValue)) {
        throw new Error(`Config "${key}": invalid default integer value "${defaultValue}"`);
    }
    const raw = get(key);
    if (raw === undefined || raw === null || raw === '')
        return defaultValue;
    const parsed = parseInt(String(raw).trim(), 10);
    if (Number.isNaN(parsed)) {
        throw new Error(`Config "${key}": invalid integer value "${raw}"`);
    }
    return parsed;
};
const configBoolean = (key, defaultValue = false) => {
    if (typeof defaultValue !== 'boolean') {
        throw new Error(`Config "${key}": invalid default boolean value "${defaultValue}"`);
    }
    const raw = get(key);
    if (raw === undefined || raw === null)
        return defaultValue;
    if (typeof raw === 'boolean')
        return raw;
    const s = String(raw).trim().toLowerCase();
    if (s === 'true' || s === '1' || s === 'yes' || s === 'on')
        return true;
    if (s === 'false' || s === '0' || s === 'no' || s === 'off' || s === '')
        return false;
    throw new Error(`Config "${key}": invalid boolean value "${raw}"`);
};
const configFloat = (key, defaultValue = 0) => {
    if (Number.isNaN(defaultValue)) {
        throw new Error(`Config "${key}": invalid default float value "${defaultValue}"`);
    }
    const raw = get(key);
    if (raw === undefined || raw === null || raw === '')
        return defaultValue;
    const parsed = parseFloat(String(raw).trim());
    if (Number.isNaN(parsed)) {
        throw new Error(`Config "${key}": invalid float value "${raw}"`);
    }
    return parsed;
};
exports.default = {
    get,
    getAllKeys,
    configBoolean,
    configInteger,
    configString,
    configFloat,
}; // export a wrapped nconf.get()
