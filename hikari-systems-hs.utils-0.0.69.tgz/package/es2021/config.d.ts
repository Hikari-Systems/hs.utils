declare const _default: {
    get: (key: string) => any;
    getAllKeys: () => string[];
    configBoolean: (key: string, defaultValue?: boolean) => boolean;
    configInteger: (key: string, defaultValue?: number) => number;
    configString: (key: string, defaultValue?: string) => string;
    configFloat: (key: string, defaultValue?: number) => number;
};
export default _default;
