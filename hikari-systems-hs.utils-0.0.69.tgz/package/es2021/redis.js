"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.healthcheck = exports.delRedisVal = exports.setRedisVal = exports.getRedisVal = void 0;
const ioredis_1 = __importDefault(require("ioredis"));
const config_1 = __importDefault(require("./config"));
const logging_1 = __importDefault(require("./logging"));
const log = (0, logging_1.default)('client:redis');
const getClient = () => {
    const redisEnabled = (config_1.default.get('redis:enabled') || 'true') === 'true';
    if (!redisEnabled) {
        log.warn('WARNING: Redis disabled in config (all lookups will return null)');
        return null;
    }
    const url = config_1.default.get('redis:url');
    const password = config_1.default.get('redis:auth') || undefined;
    return new ioredis_1.default(url, { password });
};
// hold a promise in module scope, then await the same promise to get the resolved value
// before using it each time. Assumes these objects are shareable across requests (todo: verify)
let internalRedisConn;
const ensureRedisConnection = async () => {
    if (!internalRedisConn) {
        const redisClient = getClient();
        if (!redisClient) {
            internalRedisConn = null;
        }
        else {
            redisClient.on('ready', () => {
                log.debug('General purpose redis connection available');
            });
            redisClient.on('error', (e) => {
                log.error('Error in general purpose redis connection', e);
            });
            redisClient.on('reconnecting', () => {
                log.debug('General purpose redis connection interrupted - reconnecting');
            });
            redisClient.on('end', () => {
                log.debug('General purpose redis connection is disconnected');
            });
            await redisClient.ping();
            internalRedisConn = redisClient;
        }
    }
    return internalRedisConn;
};
const getRedisVal = async (key) => {
    const redisConn = await ensureRedisConnection();
    if (!redisConn) {
        return null;
    }
    try {
        return redisConn.get(key);
    }
    catch (err) {
        log.error(`Error in getRedisVal(${key})`, err);
        throw err;
    }
};
exports.getRedisVal = getRedisVal;
const setRedisVal = async (key, value) => {
    const redisConn = await ensureRedisConnection();
    if (!redisConn) {
        return;
    }
    try {
        await redisConn.set(key, value);
    }
    catch (err) {
        log.error(`Error in setRedisVal(${key}, ${value})`, err);
        throw err;
    }
};
exports.setRedisVal = setRedisVal;
const delRedisVal = async (key) => {
    const redisConn = await ensureRedisConnection();
    if (!redisConn) {
        return;
    }
    try {
        await redisConn.del(key);
    }
    catch (err) {
        log.error(`Error in delRedisVal(${key})`, err);
        throw err;
    }
};
exports.delRedisVal = delRedisVal;
const healthcheck = () => new Promise((resolve, reject) => {
    const redisEnabled = (config_1.default.get('redis:enabled') || 'true') === 'true';
    if (!redisEnabled) {
        resolve();
        return;
    }
    const url = config_1.default.get('redis:url');
    const password = config_1.default.get('redis:auth') || undefined;
    const testClient = new ioredis_1.default(url, {
        password,
        lazyConnect: true,
    });
    const cleanup = () => {
        setTimeout(() => {
            testClient.disconnect();
        }, 20);
    };
    const errorHandler = (err) => {
        cleanup();
        reject(new Error(`Redis health check failed: err=${err}`));
    };
    testClient.once('ready', () => {
        cleanup();
        resolve();
    });
    testClient.once('error', errorHandler);
    void testClient.connect().catch(errorHandler);
});
exports.healthcheck = healthcheck;
