export declare const getRedisVal: (key: string) => Promise<string | null>;
export declare const setRedisVal: (key: string, value: string) => Promise<void>;
export declare const delRedisVal: (key: string) => Promise<void>;
export declare const healthcheck: () => Promise<void>;
