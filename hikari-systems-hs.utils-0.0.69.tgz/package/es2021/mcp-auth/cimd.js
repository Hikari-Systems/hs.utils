"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCimdHandler = void 0;
const createCimdHandler = (store) => async (req, res) => {
    const clientId = req.params.client_id;
    const registration = typeof clientId === 'string' ? await store.get(clientId) : undefined;
    res.setHeader('Content-Type', 'application/json');
    if (!registration) {
        res.status(404).json({
            error: 'not_found',
            error_description: 'No client registered with that ID',
        });
        return;
    }
    res.status(200).json(registration);
};
exports.createCimdHandler = createCimdHandler;
