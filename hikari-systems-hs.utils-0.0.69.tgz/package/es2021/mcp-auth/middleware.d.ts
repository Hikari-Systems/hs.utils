import { RequestHandler } from 'express';
import { AuthConfig } from './config';
import { JwksCache } from './stores';
export declare const createMcpAuthMiddleware: (config: AuthConfig, jwks?: JwksCache, resourcePath?: string) => RequestHandler;
