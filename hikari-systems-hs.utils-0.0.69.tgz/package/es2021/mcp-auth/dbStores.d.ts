import { AsmCache, ClientStore, DcrRateLimitStore, JwksCache } from './stores';
export type McpDataServiceOpts = {
    baseUrl?: string;
    apiKey?: string;
};
export declare const createDbClientStore: (opts?: McpDataServiceOpts) => ClientStore;
export declare const createDbDcrRateLimitStore: (opts?: McpDataServiceOpts) => DcrRateLimitStore;
export declare const createDbJwksCache: (opts?: McpDataServiceOpts) => JwksCache;
export declare const createDbAsmCache: (opts?: McpDataServiceOpts) => AsmCache;
