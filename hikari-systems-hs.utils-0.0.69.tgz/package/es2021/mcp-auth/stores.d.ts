/**
 * Shared store contracts for the MCP OAuth resource-server middleware.
 *
 * Two implementations exist:
 *   - in-memory factories in this file (good for tests and single-instance deploys)
 *   - HTTP-backed factories in `./dbStores` that call out to mcp-data-service
 *     (production multi-instance default)
 *
 * Every factory returns an async-shaped object so callers can swap freely.
 */
export type ClientRegistration = {
    client_id: string;
    client_id_issued_at: number;
    redirect_uris: string[];
    grant_types: string[];
    response_types: string[];
    token_endpoint_auth_method: string;
};
export type ClientStore = {
    get(id: string): Promise<ClientRegistration | undefined>;
    set(id: string, reg: ClientRegistration): Promise<void>;
};
export type DcrRateLimitStore = {
    /** Atomically record an attempt from `ip` and return whether it is allowed
     *  under a sliding-window limit of `max` per `windowMs`. */
    recordAndCheck(ip: string, windowMs: number, max: number): Promise<boolean>;
};
/** Full JWKS document — opaque to us, passed straight to jose. */
export type JsonWebKeySet = {
    keys: unknown[];
};
export type JwksCacheEntry = {
    jwksUri: string;
    jwks: JsonWebKeySet;
};
export type JwksCache = {
    get(authServerUrl: string): Promise<JwksCacheEntry | undefined>;
    set(authServerUrl: string, jwksUri: string, jwks: JsonWebKeySet): Promise<void>;
};
export type AsmCacheBody = Record<string, unknown>;
export type AsmCache = {
    /** Returns the cached body if present and younger than `ttlMs`. */
    get(asmUri: string, ttlMs: number): Promise<AsmCacheBody | undefined>;
    set(asmUri: string, body: AsmCacheBody): Promise<void>;
};
export declare const createClientStore: () => ClientStore;
export declare const createDcrRateLimitStore: () => DcrRateLimitStore;
export declare const createJwksCache: () => JwksCache;
export declare const createAsmCache: () => AsmCache;
