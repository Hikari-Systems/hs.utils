"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDbAsmCache = exports.createDbJwksCache = exports.createDbDcrRateLimitStore = exports.createDbClientStore = void 0;
const config_1 = __importDefault(require("../config"));
const logging_1 = __importDefault(require("../logging"));
const log = (0, logging_1.default)('mcp-auth:dbStores');
const resolveOpts = (opts) => {
    const baseUrl = (opts?.baseUrl ??
        config_1.default.configString('mcpDataService:url', 'http://mcp-data-service:3000'))
        .trim()
        .replace(/\/+$/, '');
    const apiKey = (opts?.apiKey ?? config_1.default.configString('mcpDataService:apiKey', '')).trim();
    if (baseUrl === '') {
        throw new Error('mcp-data-service: baseUrl is empty; set "mcpDataService:url" in config.');
    }
    return { baseUrl, apiKey };
};
const buildUrl = (baseUrl, pathAndQuery) => {
    const pq = pathAndQuery.startsWith('/') ? pathAndQuery : `/${pathAndQuery}`;
    return `${baseUrl}${pq}`;
};
const dataFetch = async (resolved, pathAndQuery, opts = {}) => {
    const method = opts.method ?? 'GET';
    const body = opts.body !== undefined ? JSON.stringify(opts.body) : undefined;
    const headers = { 'X-Api-Key': resolved.apiKey };
    if (body !== undefined)
        headers['Content-Type'] = 'application/json';
    return fetch(buildUrl(resolved.baseUrl, pathAndQuery), {
        method,
        headers,
        body,
    });
};
const formatError = async (response, url) => {
    const text = await response.text();
    const trimmed = text.length > 500 ? `${text.slice(0, 500)}…` : text;
    return `mcp-data-service HTTP ${response.status} for ${url}: ${trimmed}`;
};
const rawToRegistration = (raw) => ({
    client_id: raw.client_id,
    client_id_issued_at: Number(raw.client_id_issued_at),
    redirect_uris: raw.redirect_uris,
    grant_types: raw.grant_types,
    response_types: raw.response_types,
    token_endpoint_auth_method: raw.token_endpoint_auth_method,
});
const createDbClientStore = (opts) => {
    const resolved = resolveOpts(opts);
    return {
        get: async (id) => {
            const path = `/api/mcpClient/${encodeURIComponent(id)}`;
            const response = await dataFetch(resolved, path);
            if (response.status === 204 || response.status === 404)
                return undefined;
            if (!response.ok) {
                const msg = await formatError(response, buildUrl(resolved.baseUrl, path));
                log.error(msg);
                throw new Error(msg);
            }
            const raw = (await response.json());
            return rawToRegistration(raw);
        },
        set: async (id, reg) => {
            const path = `/api/mcpClient/${encodeURIComponent(id)}`;
            const response = await dataFetch(resolved, path, {
                method: 'PUT',
                body: {
                    client_id_issued_at: reg.client_id_issued_at,
                    redirect_uris: reg.redirect_uris,
                    grant_types: reg.grant_types,
                    response_types: reg.response_types,
                    token_endpoint_auth_method: reg.token_endpoint_auth_method,
                },
            });
            if (!response.ok) {
                const msg = await formatError(response, buildUrl(resolved.baseUrl, path));
                log.error(msg);
                throw new Error(msg);
            }
        },
    };
};
exports.createDbClientStore = createDbClientStore;
// ─── DcrRateLimitStore ──────────────────────────────────────────────────────
const createDbDcrRateLimitStore = (opts) => {
    const resolved = resolveOpts(opts);
    return {
        recordAndCheck: async (ip, windowMs, max) => {
            const path = '/api/mcpDcrAttempt/recordAndCheck';
            const response = await dataFetch(resolved, path, {
                method: 'POST',
                body: { ip, windowMs, max },
            });
            if (!response.ok) {
                const msg = await formatError(response, buildUrl(resolved.baseUrl, path));
                log.error(msg);
                throw new Error(msg);
            }
            const body = (await response.json());
            return Boolean(body.allowed);
        },
    };
};
exports.createDbDcrRateLimitStore = createDbDcrRateLimitStore;
const createDbJwksCache = (opts) => {
    const resolved = resolveOpts(opts);
    return {
        get: async (authServerUrl) => {
            const path = `/api/mcpJwksCache/byAuthServer?authServerUrl=${encodeURIComponent(authServerUrl)}`;
            const response = await dataFetch(resolved, path);
            if (response.status === 204 || response.status === 404)
                return undefined;
            if (!response.ok) {
                const msg = await formatError(response, buildUrl(resolved.baseUrl, path));
                log.error(msg);
                throw new Error(msg);
            }
            const raw = (await response.json());
            return { jwksUri: raw.jwks_uri, jwks: raw.jwks_document };
        },
        set: async (authServerUrl, jwksUri, jwks) => {
            const path = '/api/mcpJwksCache/byAuthServer';
            const response = await dataFetch(resolved, path, {
                method: 'PUT',
                body: {
                    auth_server_url: authServerUrl,
                    jwks_uri: jwksUri,
                    jwks_document: jwks,
                },
            });
            if (!response.ok) {
                const msg = await formatError(response, buildUrl(resolved.baseUrl, path));
                log.error(msg);
                throw new Error(msg);
            }
        },
    };
};
exports.createDbJwksCache = createDbJwksCache;
const createDbAsmCache = (opts) => {
    const resolved = resolveOpts(opts);
    return {
        get: async (asmUri, ttlMs) => {
            const path = `/api/mcpAsmCache/byUri?asmUri=${encodeURIComponent(asmUri)}&ttlMs=${ttlMs}`;
            const response = await dataFetch(resolved, path);
            if (response.status === 204 || response.status === 404)
                return undefined;
            if (!response.ok) {
                const msg = await formatError(response, buildUrl(resolved.baseUrl, path));
                log.error(msg);
                throw new Error(msg);
            }
            const raw = (await response.json());
            return raw.body;
        },
        set: async (asmUri, body) => {
            const path = '/api/mcpAsmCache/byUri';
            const response = await dataFetch(resolved, path, {
                method: 'PUT',
                body: { asm_uri: asmUri, body },
            });
            if (!response.ok) {
                const msg = await formatError(response, buildUrl(resolved.baseUrl, path));
                log.error(msg);
                throw new Error(msg);
            }
        },
    };
};
exports.createDbAsmCache = createDbAsmCache;
