import express from 'express';
import './types';
import { AuthConfig } from './config';
import { AsmCache, ClientStore, DcrRateLimitStore, JwksCache } from './stores';
export type { AuthConfig } from './config';
export { loadAuthConfig } from './config';
export { handleProtectedResourceMetadata, handleAuthServerMetadata, normalizeResourcePath, } from './discovery';
export { createTokenVerifier, TokenVerificationError } from './tokenVerifier';
export type { VerificationReason } from './tokenVerifier';
export { createMcpAuthMiddleware } from './middleware';
export { createDcrHandler } from './dcr';
export { createCimdHandler } from './cimd';
export type { AsmCache, AsmCacheBody, ClientRegistration, ClientStore, DcrRateLimitStore, JsonWebKeySet, JwksCache, JwksCacheEntry, } from './stores';
export { createAsmCache, createClientStore, createDcrRateLimitStore, createJwksCache, } from './stores';
export type { McpDataServiceOpts } from './dbStores';
export { createDbAsmCache, createDbClientStore, createDbDcrRateLimitStore, createDbJwksCache, } from './dbStores';
export type McpAuthStores = {
    clients?: ClientStore;
    rateLimit?: DcrRateLimitStore;
    jwks?: JwksCache;
    asm?: AsmCache;
};
export type McpAuthOptions = McpAuthStores & {
    resourcePath?: string;
};
export declare const applyMcpAuth: (app: express.IRouter, config: AuthConfig, options?: McpAuthOptions) => void;
