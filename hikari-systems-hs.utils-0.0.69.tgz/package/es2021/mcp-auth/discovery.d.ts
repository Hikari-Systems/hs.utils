import { RequestHandler } from 'express';
import { AuthConfig } from './config';
import { AsmCache } from './stores';
export declare const normalizeResourcePath: (raw: string | undefined) => string;
export declare const handleProtectedResourceMetadata: (config: AuthConfig, resourcePath?: string) => RequestHandler;
export declare const handleAuthServerMetadata: (config: AuthConfig, cache?: AsmCache) => RequestHandler;
