"use strict";
/**
 * Shared store contracts for the MCP OAuth resource-server middleware.
 *
 * Two implementations exist:
 *   - in-memory factories in this file (good for tests and single-instance deploys)
 *   - HTTP-backed factories in `./dbStores` that call out to mcp-data-service
 *     (production multi-instance default)
 *
 * Every factory returns an async-shaped object so callers can swap freely.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAsmCache = exports.createJwksCache = exports.createDcrRateLimitStore = exports.createClientStore = void 0;
// ─── In-memory implementations ──────────────────────────────────────────────
const createClientStore = () => {
    const store = new Map();
    return {
        get: async (id) => store.get(id),
        set: async (id, reg) => {
            store.set(id, reg);
        },
    };
};
exports.createClientStore = createClientStore;
const createDcrRateLimitStore = () => {
    const store = new Map();
    return {
        recordAndCheck: async (ip, windowMs, max) => {
            const now = Date.now();
            const window = (store.get(ip) ?? []).filter((t) => now - t < windowMs);
            if (window.length >= max) {
                store.set(ip, window);
                return false;
            }
            window.push(now);
            store.set(ip, window);
            return true;
        },
    };
};
exports.createDcrRateLimitStore = createDcrRateLimitStore;
const createJwksCache = () => {
    const store = new Map();
    return {
        get: async (authServerUrl) => store.get(authServerUrl),
        set: async (authServerUrl, jwksUri, jwks) => {
            store.set(authServerUrl, { jwksUri, jwks });
        },
    };
};
exports.createJwksCache = createJwksCache;
const createAsmCache = () => {
    const store = new Map();
    return {
        get: async (asmUri, ttlMs) => {
            const entry = store.get(asmUri);
            if (!entry)
                return undefined;
            if (Date.now() - entry.fetchedAt >= ttlMs)
                return undefined;
            return entry.body;
        },
        set: async (asmUri, body) => {
            store.set(asmUri, { fetchedAt: Date.now(), body });
        },
    };
};
exports.createAsmCache = createAsmCache;
