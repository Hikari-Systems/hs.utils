"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTokenVerifier = exports.TokenVerificationError = void 0;
const jose_1 = require("jose");
const stores_1 = require("./stores");
class TokenVerificationError extends Error {
    constructor(reason, message) {
        super(message ?? reason);
        this.name = 'TokenVerificationError';
        this.reason = reason;
    }
}
exports.TokenVerificationError = TokenVerificationError;
const fetchJson = async (url) => {
    const response = await fetch(url, {
        headers: { Accept: 'application/json' },
    });
    if (!response.ok) {
        throw new TokenVerificationError('unknown', `HTTP ${response.status} fetching ${url}`);
    }
    return response.json();
};
const discoverJwksUri = async (config) => {
    if (config.jwksUri)
        return config.jwksUri;
    const upstream = `${config.authorizationServerUrl.replace(/\/+$/, '')}/.well-known/oauth-authorization-server`;
    const meta = (await fetchJson(upstream));
    if (typeof meta.jwks_uri !== 'string' || meta.jwks_uri === '') {
        throw new TokenVerificationError('unknown', `Authorization server metadata at ${upstream} did not include a jwks_uri.`);
    }
    return meta.jwks_uri;
};
const fetchJwks = async (jwksUri) => {
    const body = (await fetchJson(jwksUri));
    if (!body || typeof body !== 'object' || !Array.isArray(body.keys)) {
        throw new TokenVerificationError('unknown', `JWKS at ${jwksUri} did not contain a "keys" array.`);
    }
    return body;
};
const mapJoseError = (err) => {
    if (err instanceof TokenVerificationError)
        return err;
    if (err instanceof jose_1.errors.JWTExpired) {
        return new TokenVerificationError('expired', 'Token has expired');
    }
    if (err instanceof jose_1.errors.JWTClaimValidationFailed) {
        if (err.claim === 'aud') {
            return new TokenVerificationError('wrong_audience', 'Token audience does not match expected resource');
        }
        return new TokenVerificationError('unknown', `Claim validation failed: ${err.claim}`);
    }
    if (err instanceof jose_1.errors.JWSSignatureVerificationFailed ||
        err instanceof jose_1.errors.JWKSNoMatchingKey) {
        return new TokenVerificationError('invalid_signature', 'Token signature could not be verified');
    }
    if (err instanceof jose_1.errors.JWTInvalid ||
        err instanceof jose_1.errors.JWSInvalid) {
        return new TokenVerificationError('malformed', 'Token is malformed');
    }
    return new TokenVerificationError('unknown');
};
const createTokenVerifier = (config, cache = (0, stores_1.createJwksCache)()) => async (token) => {
    if (typeof token !== 'string' || token.length === 0) {
        throw new TokenVerificationError('malformed', 'Empty token');
    }
    const cached = await cache.get(config.authorizationServerUrl);
    let jwksDoc;
    let jwksUri;
    if (cached) {
        ({ jwks: jwksDoc, jwksUri } = cached);
    }
    else {
        jwksUri = await discoverJwksUri(config);
        jwksDoc = await fetchJwks(jwksUri);
        await cache.set(config.authorizationServerUrl, jwksUri, jwksDoc);
    }
    const keySet = (0, jose_1.createLocalJWKSet)(jwksDoc);
    try {
        const { payload } = await (0, jose_1.jwtVerify)(token, keySet, {
            issuer: config.authorizationServerUrl,
            audience: config.expectedAudience,
            clockTolerance: config.clockSkewSeconds,
        });
        return payload;
    }
    catch (err) {
        throw mapJoseError(err);
    }
};
exports.createTokenVerifier = createTokenVerifier;
