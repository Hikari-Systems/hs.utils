import { JWTPayload } from 'jose';
import { AuthConfig } from './config';
import { JwksCache } from './stores';
export type VerificationReason = 'expired' | 'invalid_signature' | 'wrong_audience' | 'malformed' | 'unknown';
export declare class TokenVerificationError extends Error {
    readonly reason: VerificationReason;
    constructor(reason: VerificationReason, message?: string);
}
export declare const createTokenVerifier: (config: AuthConfig, cache?: JwksCache) => (token: string) => Promise<JWTPayload>;
