"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.applyMcpAuth = exports.createDbJwksCache = exports.createDbDcrRateLimitStore = exports.createDbClientStore = exports.createDbAsmCache = exports.createJwksCache = exports.createDcrRateLimitStore = exports.createClientStore = exports.createAsmCache = exports.createCimdHandler = exports.createDcrHandler = exports.createMcpAuthMiddleware = exports.TokenVerificationError = exports.createTokenVerifier = exports.normalizeResourcePath = exports.handleAuthServerMetadata = exports.handleProtectedResourceMetadata = exports.loadAuthConfig = void 0;
const express_1 = __importDefault(require("express"));
require("./types");
const discovery_1 = require("./discovery");
const middleware_1 = require("./middleware");
const dcr_1 = require("./dcr");
const cimd_1 = require("./cimd");
const dbStores_1 = require("./dbStores");
var config_1 = require("./config");
Object.defineProperty(exports, "loadAuthConfig", { enumerable: true, get: function () { return config_1.loadAuthConfig; } });
var discovery_2 = require("./discovery");
Object.defineProperty(exports, "handleProtectedResourceMetadata", { enumerable: true, get: function () { return discovery_2.handleProtectedResourceMetadata; } });
Object.defineProperty(exports, "handleAuthServerMetadata", { enumerable: true, get: function () { return discovery_2.handleAuthServerMetadata; } });
Object.defineProperty(exports, "normalizeResourcePath", { enumerable: true, get: function () { return discovery_2.normalizeResourcePath; } });
var tokenVerifier_1 = require("./tokenVerifier");
Object.defineProperty(exports, "createTokenVerifier", { enumerable: true, get: function () { return tokenVerifier_1.createTokenVerifier; } });
Object.defineProperty(exports, "TokenVerificationError", { enumerable: true, get: function () { return tokenVerifier_1.TokenVerificationError; } });
var middleware_2 = require("./middleware");
Object.defineProperty(exports, "createMcpAuthMiddleware", { enumerable: true, get: function () { return middleware_2.createMcpAuthMiddleware; } });
var dcr_2 = require("./dcr");
Object.defineProperty(exports, "createDcrHandler", { enumerable: true, get: function () { return dcr_2.createDcrHandler; } });
var cimd_2 = require("./cimd");
Object.defineProperty(exports, "createCimdHandler", { enumerable: true, get: function () { return cimd_2.createCimdHandler; } });
var stores_1 = require("./stores");
Object.defineProperty(exports, "createAsmCache", { enumerable: true, get: function () { return stores_1.createAsmCache; } });
Object.defineProperty(exports, "createClientStore", { enumerable: true, get: function () { return stores_1.createClientStore; } });
Object.defineProperty(exports, "createDcrRateLimitStore", { enumerable: true, get: function () { return stores_1.createDcrRateLimitStore; } });
Object.defineProperty(exports, "createJwksCache", { enumerable: true, get: function () { return stores_1.createJwksCache; } });
var dbStores_2 = require("./dbStores");
Object.defineProperty(exports, "createDbAsmCache", { enumerable: true, get: function () { return dbStores_2.createDbAsmCache; } });
Object.defineProperty(exports, "createDbClientStore", { enumerable: true, get: function () { return dbStores_2.createDbClientStore; } });
Object.defineProperty(exports, "createDbDcrRateLimitStore", { enumerable: true, get: function () { return dbStores_2.createDbDcrRateLimitStore; } });
Object.defineProperty(exports, "createDbJwksCache", { enumerable: true, get: function () { return dbStores_2.createDbJwksCache; } });
const applyMcpAuth = (app, config, options = {}) => {
    const clients = options.clients ?? (0, dbStores_1.createDbClientStore)();
    const rateLimit = options.rateLimit ?? (0, dbStores_1.createDbDcrRateLimitStore)();
    const jwks = options.jwks ?? (0, dbStores_1.createDbJwksCache)();
    const asm = options.asm ?? (0, dbStores_1.createDbAsmCache)();
    const resourcePath = (0, discovery_1.normalizeResourcePath)(options.resourcePath);
    // Bare path serves the host-root PRM; the path-suffix variant is required
    // by RFC 9728 when the resource is at a sub-path. Register both so legacy
    // clients hitting the bare path still get a useful response.
    app.get('/.well-known/oauth-protected-resource', (0, discovery_1.handleProtectedResourceMetadata)(config, resourcePath));
    if (resourcePath !== '') {
        app.get(`/.well-known/oauth-protected-resource${resourcePath}`, (0, discovery_1.handleProtectedResourceMetadata)(config, resourcePath));
    }
    app.get('/.well-known/oauth-authorization-server', (0, discovery_1.handleAuthServerMetadata)(config, asm));
    app.get('/.well-known/client-metadata/:client_id', (0, cimd_1.createCimdHandler)(clients));
    if (config.enableDcr) {
        app.post('/register', express_1.default.json(), (0, dcr_1.createDcrHandler)(config, clients, rateLimit));
    }
    app.use((0, middleware_1.createMcpAuthMiddleware)(config, jwks, resourcePath));
};
exports.applyMcpAuth = applyMcpAuth;
