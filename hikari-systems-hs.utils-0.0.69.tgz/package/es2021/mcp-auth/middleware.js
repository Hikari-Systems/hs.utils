"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createMcpAuthMiddleware = void 0;
const forwardedFor_1 = require("../forwardedFor");
const discovery_1 = require("./discovery");
const tokenVerifier_1 = require("./tokenVerifier");
const stores_1 = require("./stores");
const buildWwwAuthenticate = (req, resourcePath) => {
    const { baseUrl } = (0, forwardedFor_1.forwardedFor)(req);
    return (`Bearer realm="${baseUrl}${resourcePath}", ` +
        `resource_metadata="${baseUrl}/.well-known/oauth-protected-resource${resourcePath}"`);
};
const createMcpAuthMiddleware = (config, jwks = (0, stores_1.createJwksCache)(), resourcePath = '') => {
    const verify = (0, tokenVerifier_1.createTokenVerifier)(config, jwks);
    const path = (0, discovery_1.normalizeResourcePath)(resourcePath);
    return async (req, res, next) => {
        const wwwAuth = buildWwwAuthenticate(req, path);
        if (req.path.startsWith('/.well-known/')) {
            next();
            return;
        }
        if (req.method === 'POST' && req.path === '/register') {
            next();
            return;
        }
        const header = req.header('authorization') ?? req.header('Authorization');
        if (!header) {
            res.setHeader('WWW-Authenticate', wwwAuth);
            res.setHeader('Content-Type', 'application/json');
            res.status(401).json({
                error: 'invalid_token',
                error_description: 'Missing or malformed Authorization header',
            });
            return;
        }
        const match = /^Bearer\s+(.+)$/i.exec(header.trim());
        if (!match) {
            res.setHeader('WWW-Authenticate', wwwAuth);
            res.setHeader('Content-Type', 'application/json');
            res.status(401).json({
                error: 'invalid_token',
                error_description: 'Missing or malformed Authorization header',
            });
            return;
        }
        const token = match[1].trim();
        try {
            const payload = await verify(token);
            req.mcpAuthToken = payload;
            next();
        }
        catch (err) {
            const reason = err instanceof tokenVerifier_1.TokenVerificationError ? err.reason : 'unknown';
            res.setHeader('WWW-Authenticate', wwwAuth);
            res.setHeader('Content-Type', 'application/json');
            const body = {
                error: 'invalid_token',
            };
            if (reason === 'expired')
                body.error_description = 'Token has expired';
            else if (reason === 'wrong_audience')
                body.error_description = 'Token audience mismatch';
            res.status(401).json(body);
        }
    };
};
exports.createMcpAuthMiddleware = createMcpAuthMiddleware;
