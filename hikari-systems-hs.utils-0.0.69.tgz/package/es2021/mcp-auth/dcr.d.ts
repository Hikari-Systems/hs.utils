import { RequestHandler } from 'express';
import { AuthConfig } from './config';
import { ClientRegistration, ClientStore, DcrRateLimitStore, createClientStore, createDcrRateLimitStore } from './stores';
export type { ClientRegistration, ClientStore, DcrRateLimitStore };
export { createClientStore, createDcrRateLimitStore };
export declare const createDcrHandler: (_config: AuthConfig, store: ClientStore, rateLimit: DcrRateLimitStore) => RequestHandler;
