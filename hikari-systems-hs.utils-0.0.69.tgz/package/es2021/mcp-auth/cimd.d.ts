import { RequestHandler } from 'express';
import { ClientStore } from './stores';
export declare const createCimdHandler: (store: ClientStore) => RequestHandler;
