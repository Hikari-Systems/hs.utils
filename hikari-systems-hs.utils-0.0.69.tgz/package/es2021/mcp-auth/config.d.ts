export type AuthConfig = {
    resourceServerUrl: string;
    authorizationServerUrl: string;
    supportedScopes: string[];
    expectedAudience: string;
    enableDcr: boolean;
    jwksUri?: string;
    clockSkewSeconds: number;
};
export declare const loadAuthConfig: () => AuthConfig;
