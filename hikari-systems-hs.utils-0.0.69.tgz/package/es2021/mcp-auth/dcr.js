"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDcrHandler = exports.createDcrRateLimitStore = exports.createClientStore = void 0;
const uuid_1 = require("uuid");
const stores_1 = require("./stores");
Object.defineProperty(exports, "createClientStore", { enumerable: true, get: function () { return stores_1.createClientStore; } });
Object.defineProperty(exports, "createDcrRateLimitStore", { enumerable: true, get: function () { return stores_1.createDcrRateLimitStore; } });
const RATE_LIMIT_WINDOW_MS = 60 * 1000;
const RATE_LIMIT_MAX = 5;
const isAcceptableRedirectUri = (uri) => {
    let parsed;
    try {
        parsed = new URL(uri);
    }
    catch {
        return false;
    }
    if (parsed.protocol === 'https:')
        return true;
    if (parsed.protocol === 'http:') {
        return parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1';
    }
    return false;
};
const jsonError = (res, status, error, description) => {
    res.setHeader('Content-Type', 'application/json');
    res
        .status(status)
        .json(description === undefined
        ? { error }
        : { error, error_description: description });
};
const createDcrHandler = (_config, store, rateLimit) => async (req, res) => {
    const ip = req.ip ?? req.socket.remoteAddress ?? 'unknown';
    const allowed = await rateLimit.recordAndCheck(ip, RATE_LIMIT_WINDOW_MS, RATE_LIMIT_MAX);
    if (!allowed) {
        jsonError(res, 429, 'too_many_requests', 'DCR rate limit exceeded; try again shortly.');
        return;
    }
    const { body } = req;
    if (!body || typeof body !== 'object') {
        jsonError(res, 400, 'invalid_client_metadata', 'Request body must be JSON.');
        return;
    }
    const redirectUris = body.redirect_uris;
    if (!Array.isArray(redirectUris) ||
        redirectUris.length === 0 ||
        !redirectUris.every((u) => typeof u === 'string')) {
        jsonError(res, 400, 'invalid_client_metadata', 'redirect_uris must be a non-empty array of strings.');
        return;
    }
    const badUri = redirectUris.find((uri) => !isAcceptableRedirectUri(uri));
    if (badUri !== undefined) {
        jsonError(res, 400, 'invalid_redirect_uri', `Redirect URI not permitted: ${badUri}. Use https:// or http://localhost.`);
        return;
    }
    const clientId = (0, uuid_1.v4)();
    const registration = {
        client_id: clientId,
        client_id_issued_at: Math.floor(Date.now() / 1000),
        redirect_uris: redirectUris,
        grant_types: ['authorization_code'],
        response_types: ['code'],
        token_endpoint_auth_method: 'none',
    };
    await store.set(clientId, registration);
    res.setHeader('Content-Type', 'application/json');
    res.status(201).json(registration);
};
exports.createDcrHandler = createDcrHandler;
