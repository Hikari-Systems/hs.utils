"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadAuthConfig = void 0;
const config_1 = __importDefault(require("../config"));
const requiredString = (key) => {
    const value = config_1.default.configString(key, '');
    if (value === '') {
        throw new Error(`MCP auth config: required key "${key}" is missing or empty. ` +
            `Set it in config.json or via env var "${key.replace(/:/g, '__')}".`);
    }
    return value;
};
const parseScopes = (raw) => {
    const scopes = raw
        .split(',')
        .map((s) => s.trim())
        .filter((s) => s.length > 0);
    if (scopes.length === 0) {
        throw new Error('MCP auth config: "mcp:auth:supportedScopes" must contain at least ' +
            'one comma-separated scope.');
    }
    return scopes;
};
const loadAuthConfig = () => {
    const resourceServerUrl = requiredString('mcp:auth:resourceServerUrl');
    const expectedAudience = requiredString('mcp:auth:expectedAudience');
    const supportedScopes = parseScopes(requiredString('mcp:auth:supportedScopes'));
    const authorizationServerUrl = config_1.default.configString('oauth2:authorizationServer', 'https://sso.hikari-systems.com');
    const enableDcr = config_1.default.configBoolean('mcp:auth:enableDcr', false);
    const clockSkewSeconds = config_1.default.configInteger('mcp:auth:clockSkewSeconds', 30);
    const jwksUriRaw = config_1.default.configString('mcp:auth:jwksUri', '');
    const jwksUri = jwksUriRaw === '' ? undefined : jwksUriRaw;
    return {
        resourceServerUrl,
        authorizationServerUrl,
        supportedScopes,
        expectedAudience,
        enableDcr,
        jwksUri,
        clockSkewSeconds,
    };
};
exports.loadAuthConfig = loadAuthConfig;
